// This is a counter variable that is set to zero
var likeCount = 0;
// The function of the code block is to increment the likeCount by 1
function increaseLikes() {
  // The likeCount variable is adding one every time the function is called
  likeCount = likeCount + 1;
}
