//We need a loop here because the task is repetitive and needs to be done more than ones.
//The starting point of the loop should be the loop
//The loop should stop when the person reaches the 6 miles.
//The loop will know when to stop because we will create the condition.
//The iteration is going to be 2.
//We need the i variable. for the bonus we need a variable to store the runners speed.

for (var i = 2; i < 6; i += 2) {
  console.log("Give Candy!");
}

//Bonus
var runnerSpeed = 5.6;

for (var i = 2; i < 6; i += 2) {
  if (runnerSpeed > 5.5) {
    console.log("Give Candy!");
  }
}
