//Variables for the program to determine age and height requirement to ride the rollercoaster

min_age = 10;  //minimum age required to ride the rollercoaster variable
min_height = 42; //minimum height required to ride the rollercoaster variable