var min_age = 10;  
var min_height = 43;

//if(min_age >=10 && min_height >= 42) {

  if (min_height >42)
{
    console.log("Get on that ride, kiddo!");
}

else {
    console.log("Sorry kiddo. Maybe next year");
}

//Stretch Feature 1:
 if (min_height >=42 && min_age >=10)
{
    console.log("Get on that ride, kiddo!");
}

else {
    console.log("Sorry kiddo. Maybe next year");
}

////Stretch Feature 2:
 if (min_height >=42 || min_age >=10)
{
    console.log("Get on that ride, kiddo!");
}

else {
    console.log("Sorry kiddo. Maybe next year");
}