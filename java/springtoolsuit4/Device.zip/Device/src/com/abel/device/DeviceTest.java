package com.abel.device;

public class DeviceTest {

	public static void main(String[] args) {
		Phone phoneActivity = new Phone();
		
		phoneActivity.makeCall();
		phoneActivity.makeCall();
		phoneActivity.makeCall();
		phoneActivity.playGame();
		phoneActivity.playGame();
		phoneActivity.charging();
		

	}

}
