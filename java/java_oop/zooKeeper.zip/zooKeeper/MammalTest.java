public class MammalTest {
    public static void main(String[] args) {
        // // Gorilla test
        // Gorilla theGorilla = new Gorilla();
        // theGorilla.throwSomething();
        // theGorilla.throwSomething();
        // theGorilla.throwSomething();
        // theGorilla.eatBananas();
        // theGorilla.eatBananas();
        // theGorilla.Climb();
        // System.out.println(theGorilla.getEnergy());

        // Bat test
        Bat theBat = new Bat();
        theBat.attackTown();
        theBat.attackTown();
        theBat.attackTown();
        theBat.eatHumans();
        theBat.eatHumans();
        theBat.fly();
        theBat.fly();
        System.out.println(theBat.getEnergy());

    }
    
}
